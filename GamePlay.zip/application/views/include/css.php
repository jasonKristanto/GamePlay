<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/dataTables.bootstrap.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/admin.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/flaticon.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/Animate.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/summernote/summernote.css'); ?>">
