<footer class="footer">
	<div class="container text-center">
		<p> Copyright 2019 - GamePlay </p>
	</div>
</footer>

<style type="text/css">
	.footer {
		position: fixed;
		left: 0;
		bottom: 0;
		width: 100%;
		background-color: grey;
		color: #EEEEEE;
		text-align: center;
	}
</style>